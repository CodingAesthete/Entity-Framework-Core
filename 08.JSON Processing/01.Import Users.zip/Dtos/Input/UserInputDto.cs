﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos.Input
{
    public class UserInputDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int? Age { get; set; } //0
    }
}
